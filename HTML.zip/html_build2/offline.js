﻿{
	"version": 1584901650,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/kletka_blue-sheet0.png",
		"images/kletka_red-sheet0.png",
		"images/eda-sheet0.png",
		"images/spawner-sheet0.png",
		"images/kletka_yellow-sheet0.png",
		"images/kletka_green-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}